#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

// DEBUG: descomenta para ver la luz recibida por la capa B como rojo (1.0 = rojo puro)
// Sin descarte. Junto al note block la cara de stone debe salir roja pura.
//#define DEBUG_LIGHT

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 dbgLight;
flat in float layerB;

out vec4 fragColor;

void main() {
    vec4 texel = texture(Sampler0, texCoord0);

    // Marcador: los bloques custom tienen alfa 252/255 (0.988) en sus pixeles opacos.
    // textureLod nivel 0 -> el mipmapping no emborrona el marcador.
    float marker = textureLod(Sampler0, texCoord0, 0.0).a;
    bool isCustom = marker > 0.986 && marker < 0.990;

    // LIGHT_MIN:    custom oculto si la luz de bloque delante es > 14/15 (con margen).
    // LIGHT_LINEAL: capa B visible solo si la luz de la celda de enfrente es 15 (1.0).
    const float LIGHT_MIN = 0.93;
    const float LIGHT_LINEAL = 0.98;
    float L = dbgLight.x;   // solo luz de bloque

#ifdef DEBUG_LIGHT
    if (layerB > 0.5 && !isCustom) {
        fragColor = vec4(L, 0.0, 0.0, 1.0);
        return;
    }
#endif

    if (isCustom) {
        if (L > LIGHT_MIN) discard;
    } else if (layerB > 0.5) {
        if (L < LIGHT_LINEAL) discard;
    }
    // capa A y resto del terreno: sin condicion, comportamiento vanilla

    vec4 color = texel * vertexColor * ColorModulator;

    // Quitar el marcador del resultado final
    if (isCustom) {
        color.a = 1.0;
    }

#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#else
    if (color.a < 0.1) {
        discard;
    }
#endif
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
