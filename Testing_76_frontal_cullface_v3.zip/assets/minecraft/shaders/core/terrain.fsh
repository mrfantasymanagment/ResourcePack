#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 dbgLight;

out vec4 fragColor;

void main() {
    vec4 texel = texture(Sampler0, texCoord0);

    // Marcador: los bloques custom tienen alfa 252/255 (0.988) en sus pixeles opacos.
    // textureLod nivel 0 -> el mipmapping no emborrona el marcador.
    // Rango estrecho: solo acepta 252 (251 = 0.984, 253 = 0.992 quedan fuera).
    float marker = textureLod(Sampler0, texCoord0, 0.0).a;
    bool isCustom = marker > 0.986 && marker < 0.990;

    // Luz baja (bloque delante) -> invisible, SOLO para bloques custom
    // El nivel de luz 1 del bloque emisor se lee ~0.10-0.13 (valor original, calibrado).
    // Por el smooth lighting la luz interpolada baja hacia 0 en los bordes del quad,
    // asi que se ensancha la ventana por debajo y por encima, SIN llegar a 0 (luz 0 = visible).
    //  - LIGHT_MIN: sube si se ocultan caras que no deben (zonas casi oscuras).
    //            baja si queda algun trozo visible en las caras junto al emisor.
    //  - LIGHT_MAX: tope por debajo de la luz 2 (~0.2) para no ocultar caras con mas luz.
    const float LIGHT_MIN = 0.06;
    const float LIGHT_MAX = 0.08;
    if (isCustom) {
        float L = dbgLight.x;
        vec3 dbg = L < 0.01 ? vec3(1.0, 0.0, 0.0)
                 : (L > 0.06 && L < 0.08) ? vec3(0.0, 1.0, 0.0)
                 : vec3(0.0, 0.0, 1.0);
        fragColor = vec4(dbg, 1.0);
        return;
    }

    vec4 color = texel * vertexColor * ColorModulator;

    // Quitar el marcador del resultado final
    if (isCustom) {
        color.a = 1.0;
    }

#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#else
    if (color.a < 0.1) {
        discard;
    }
#endif
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
