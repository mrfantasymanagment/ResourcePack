#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 dbgLight;

out vec4 fragColor;

void main() {
    vec4 texel = texture(Sampler0, texCoord0);

    // Marcador: los bloques custom tienen alfa 252/255 (0.988) en sus pixeles opacos.
    // textureLod nivel 0 -> el mipmapping no emborrona el marcador.
    // Rango estrecho: solo acepta 252 (251 = 0.984, 253 = 0.992 quedan fuera).
    float marker = textureLod(Sampler0, texCoord0, 0.0).a;
    bool isCustom = marker > 0.986 && marker < 0.990;

    // Luz baja (bloque delante) -> invisible, SOLO para bloques custom
    if (isCustom) {
        float L = max(dbgLight.x, dbgLight.y);
        if (L < 0.7) {
            discard;
        }
    }

    vec4 color = texel * vertexColor * ColorModulator;

    // Quitar el marcador del resultado final
    if (isCustom) {
        color.a = 1.0;
    }

#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#else
    if (color.a < 0.1) {
        discard;
    }
#endif
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
