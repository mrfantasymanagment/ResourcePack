#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 dbgLight;

vec4 minecraft_sample_lightmap(sampler2D lightMap, ivec2 uv) {
    return texture(lightMap, clamp(uv / 256.0, vec2(0.5 / 16.0), vec2(15.5 / 16.0)));
}

// ---------------------------------------------------------------------------
// PORTADORES (modelo block/76)
// Cada tira del modelo es un quad plano pegado a la cara lateral D del bloque,
// asi que el juego le asigna la luz de la celda vecina D (igual que hoy le da al
// quad "centro" la luz de la celda de enfrente). Aca solo se lo dibuja en la
// posicion de la tira real (cara F). La firma esta en los decimales de las
// coordenadas del modelo (inset 0.01..0.06) y se confirma con el marcador de alfa.
// Devuelve true y reubica 'p' si el vertice es un portador.
// ---------------------------------------------------------------------------
bool carrier_remap(inout vec3 p, out float shade) {
    shade = 1.0;
    vec3 P16  = Position * 16.0;
    vec3 fr   = fract(P16);
    vec3 dist = min(fr, 1.0 - fr);
    vec3 dd   = dist / 0.01;
    vec3 kk   = round(dd);

    bvec3 isInt = lessThan(dist, vec3(0.002));
    bvec3 isEps = bvec3(abs(dd.x - kk.x) < 0.3 && kk.x >= 1.0 && kk.x <= 6.0,
                        abs(dd.y - kk.y) < 0.3 && kk.y >= 1.0 && kk.y <= 6.0,
                        abs(dd.z - kk.z) < 0.3 && kk.z >= 1.0 && kk.z <= 6.0);

    if (!((isInt.x || isEps.x) && (isInt.y || isEps.y) && (isInt.z || isEps.z))) return false;
    if (int(isInt.x) + int(isInt.y) + int(isInt.z) != 1) return false;

    int iD = isInt.x ? 0 : (isInt.y ? 1 : 2);   // eje del plano pegado al vecino
    int a  = (iD == 0) ? 1 : 0;
    int b  = (iD == 2) ? 1 : 2;

    int code = (int(kk[a]) - 1) + 6 * (int(kk[b]) - 1);
    if (code >= 32) return false;

    // confirmar con el marcador de alfa 252 (algun texel alrededor del UV)
    vec2 h = 0.5 / vec2(textureSize(Sampler0, 0));
    bool marked = false;
    for (int i = 0; i < 4; i++) {
        vec2 o = vec2((i & 1) == 0 ? -h.x : h.x, (i & 2) == 0 ? -h.y : h.y);
        float al = textureLod(Sampler0, UV0 + o, 0.0).a;
        if (al > 0.986 && al < 0.990) marked = true;
    }
    // DEBUG: marcador desactivado (solo firma geometrica)

    int sD = code & 1;          // vecino del lado + (este/arriba/sur)
    int sF = (code >> 1) & 1;   // cara de la tira del lado + (arriba/sur/este)
    int fb = (code >> 2) & 1;   // eje F es b (si no, a)
    int mm = (code >> 3) & 1;   // sentido del mapeo
    int of = (code >> 4) & 1;   // copia desplazada 0.001 (las "_b" de las esquinas)

    int iF = (fb == 1) ? b : a;
    int iT = (fb == 1) ? a : b;

    vec3 cell;
    cell[a]  = floor(P16[a] / 16.0);
    cell[b]  = floor(P16[b] / 16.0);
    cell[iD] = round(P16[iD] / 16.0) - float(sD);
    vec3 l = round(P16) - cell * 16.0;          // coordenadas locales enteras 0..16

    float fl  = l[iF] - (sF == 1 ? 13.0 : 0.0);                       // 0..3
    float nDv = (sD == 1 ? 13.0 : 0.0) + (mm == 1 ? 3.0 - fl : fl);
    float o   = float(of) * 0.001;

    vec3 n;
    n[iT] = l[iT];
    n[iF] = (sF == 1) ? 16.0 - o : o;
    n[iD] = nDv;

    p = (cell * 16.0 + n) / 16.0 + ModelOffset;

    // el modelo usa shade:false -> aplicar el sombreado de la cara F real
    shade = (iF == 1) ? ((sF == 1) ? 1.0 : 0.5) : ((iF == 0) ? 0.6 : 0.8);
    return true;
}

void main() {
    vec3 pos = Position + ModelOffset;
    float carrierShade;
    bool isCarrier = carrier_remap(pos, carrierShade);

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = Color * minecraft_sample_lightmap(Sampler2, UV2);
    vertexColor.rgb *= carrierShade;
    if (isCarrier) vertexColor.rgb = mix(vertexColor.rgb, vec3(1.0, 0.0, 0.0), 0.7); // DEBUG: portadores en rojo
    texCoord0 = UV0;

    // TEST 2: luz cruda normalizada (0..1), sin marca de alfa
    dbgLight = vec2(UV2) / 240.0;
}
