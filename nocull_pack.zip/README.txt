Pack de prueba (resource pack, NO datapack) para Minecraft 1.21.8 (pack_format 64).
Quita el "cullface" de los modelos de: stone, dirt, cobblestone, grass_block.
Esas caras se dibujan siempre, aunque un bloque vecino ocluyente las tape.

Prueba (creativo): pon un bloque de tierra/piedra/cesped en el suelo y encima tu note block
con textura transparente. Si el suelo se ve a traves de la transparencia, la idea funciona.
Costo: mas geometria dibujada (caras ocultas) en esos bloques. Para otros bloques hay que
copiar su modelo sin "cullface" (o sobrescribir block/cube.json, que afecta a casi todos).
